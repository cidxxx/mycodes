from django.contrib import admin
from .models import Posts


class AdminBlog(admin.ModelAdmin):
    list_display = ['title', 'body', 'author']



admin.site.register(Posts, AdminBlog)
