from django.shortcuts import render, redirect
from django.views.generic import ListView, DetailView, UpdateView, CreateView, DeleteView
from django.contrib.auth.decorators import login_required
from .models import Posts
from . forms import *
from django.urls import reverse_lazy
from django.views import generic
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import logout





class RegistrationView(generic.CreateView):
    form_class = UserCreationForm
    template_name = 'registration/register.html'
    success_url = reverse_lazy('login')





class ArticleUpload(CreateView):
    queryset = Posts.objects.all()
    template_name = 'home.html'
    form_class = UploadPosts









def python_blog(request):
    return render (request, 'pythonblog.html')








class HomeView(ListView):
    model = Posts
    template_name = 'blogs.html'
    ordering = ['-date']






class ArticleUpdateView(UpdateView):
    model = Posts
    template_name = 'article_update.html'
    fields = ('title', 'body', 'date', 'nin')





class ArticleDetailView(DetailView):
    model = Posts
    template_name = 'article_detail.html'
    



class ArticleDelete(DeleteView):
    model = Posts
    template_name = 'article_delete.html'
    queryset = Posts.objects.all()
    success_url = reverse_lazy('home')


    




def logout_view(request):
    logout(request)
    return redirect('login')
   



    

   





















def search_bar (request):
    queryset = ''
    queryset1 = ''


    context ={
        'queryset':queryset,
        'queryset1':queryset1
    }
    if request.method == 'GET':
        queryset = request.GET.get('search')
        queryset1 =  Posts.objects.filter(nin__icontains=queryset)


        context = {
            'queryset':queryset,
            'queryset1':queryset1
        }


        
    return render  (request, 'searchblog.html', context)
 






































































