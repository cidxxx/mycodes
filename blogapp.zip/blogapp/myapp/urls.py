from django.urls import path
from . import views
from django.contrib.auth.decorators import login_required




urlpatterns = [
    path('upload', login_required (views.ArticleUpload.as_view()), name='upload'),
    path('', views.python_blog, name='home_page'),
    path('posts', views.HomeView.as_view(), name='home'),
    path('search/', views.search_bar, name= 'search'),
    path('detail/<int:pk>', views.ArticleDetailView.as_view(), name='article-detail'),
    path('update/<int:pk>', views.ArticleUpdateView.as_view(), name='update'),
    path('delete/<int:pk>', views.ArticleDelete.as_view(), name='delete' ),
    path('register/', views.RegistrationView.as_view(), name='register'),
    path('account/logout/', views.logout_view, name='logout'),
 
]



