from django import forms
from . models import *

class UploadPosts(forms.ModelForm):
    class Meta:
        model = Posts
        fields = ['title', 'body', 'author', 'date', 'nin']